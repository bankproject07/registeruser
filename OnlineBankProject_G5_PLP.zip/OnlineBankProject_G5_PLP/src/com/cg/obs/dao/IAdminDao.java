package com.cg.obs.dao;

import java.sql.Date;
import java.util.List;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.Transactions;
import com.cg.obs.exception.UserException;

public interface IAdminDao {

	public Admin getAdmin() throws UserException;
	public int addUsers(Customer customer) throws UserException;
	public int addUsers(AccountMaster accountMaster) throws UserException;
	public Customer getCustomerbyId(int id) throws UserException;
	public boolean isCustomerExist(int id) throws UserException;
	
	public List<Transactions> viewMonthlyReport(Date StartDate,Date EndDate) throws UserException;
	public List<Transactions> viewYearlyReport(Date StartDate,Date EndDate) throws UserException;
	public List<Transactions> viewDailyReport(Date StartDate) throws UserException;
	
	public List<RequestTable> getAllRequest() throws UserException;
}
