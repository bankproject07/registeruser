package com.cg.obs.controller;


import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.controller.BindingResult;
import com.capgemini.controller.Model;
import com.capgemini.controller.ModelAndView;
import com.capgemini.controller.ModelAttribute;
import com.capgemini.entities.Product;
import com.cg.obs.bean.Users;
import com.cg.obs.service.IUserService;



@Controller
public class BankingApplicationController {

	
	@Autowired
	IUserService userService;
	
	public BankingApplicationController() {
		// TODO Auto-generated constructor stub
	}

	public IUserService getUserService() {
		return userService;
	}

	public void setUserService(IUserService userService) {
		this.userService = userService;
	}

	public BankingApplicationController(IUserService userService) {
		super();
		this.userService = userService;
	}
	
	
	@RequestMapping("Login")
	public String getLoginPage(@RequestParam("username") int userId,@RequestParam("password") String password){
		
		Users user=userService.getUser(userId);
		System.out.println(user);
		if(user!=null)
		{
			
			
		if(password.equalsIgnoreCase(user.getLoginPassword()))
		{
			System.out.println("user login success");
			return "index";
		}
		
		
	}
		
			return "pages/ErrorPage";
			
		
	
	}
	
	@RequestMapping("registerUser")
	public String getRegisterUserPage(Model model)
	{
		List<String> types = new ArrayList<>();
		types.add("Saving Account");
		types.add("Current Account");
		
		//Add the form backing bean to be binded to AddProduct.jsp Form
		model.addAttribute("user",new Users());

		//Add categories to build the drop down list in AddProduct dynamically
		model.addAttribute("types", types);

		//return view name
		return "RegisterUserPage";

	}
	
	@RequestMapping(value="ProcessRegisterUserForm")
	public ModelAndView getProcessRegisterUserForm(@ModelAttribute("user") 
	@Valid Users user,BindingResult result,Model model)
	{
		if (result.hasErrors() == true) 
		{
			List<String> types = new ArrayList<>();
			types.add("Saving Account");
			types.add("Current Account");

			//Add the form backing bean to be binded to AddProduct.jsp Form
			model.addAttribute("user",new Users());

			//Add categories to build the drop down list in AddProduct dynamically
			model.addAttribute("types", types);

			return new ModelAndView("RegisterUserPage");
		}

		int Id=-1;

		try 
		{
			Id = userService.registerUser(user);
			model.addAttribute("message",
					"User Successfully. ");
			return new ModelAndView("SuccessPage");
		} 
		catch (Exception e) 
		{
			model.addAttribute("errMsg","Could not register User. Reason is " + e.getMessage());
			return new ModelAndView("ErrorPage");
		}

	}
}
